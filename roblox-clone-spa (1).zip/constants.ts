import { Game, User } from './types';

export const INITIAL_USER: User = {
  username: 'RobloxPlayer123',
  robux: 1250,
  avatarColors: {
    head: '#e8beac',
    torso: '#00a2ff',
    leftArm: '#e8beac',
    rightArm: '#e8beac',
    leftLeg: '#1b1b1b',
    rightLeg: '#1b1b1b',
  }
};

export const MOCK_GAMES: Game[] = [
  {
    id: '1',
    title: 'Brookhaven RP',
    creator: 'Wolfpaq',
    playing: 452000,
    rating: 4.5,
    imageUrl: 'https://picsum.photos/400/225?random=1',
    category: 'RP'
  },
  {
    id: '2',
    title: 'Adopt Me!',
    creator: 'DreamCraft',
    playing: 125000,
    rating: 4.8,
    imageUrl: 'https://picsum.photos/400/225?random=2',
    category: 'RP'
  },
  {
    id: '3',
    title: 'Blox Fruits',
    creator: 'Gamer Robot Inc',
    playing: 670000,
    rating: 4.9,
    imageUrl: 'https://picsum.photos/400/225?random=3',
    category: 'Adventure'
  },
  {
    id: '4',
    title: 'Tower of Hell',
    creator: 'YXCeptional Studios',
    playing: 32000,
    rating: 4.0,
    imageUrl: 'https://picsum.photos/400/225?random=4',
    category: 'Obby'
  },
  {
    id: '5',
    title: 'Arsenal',
    creator: 'ROLVe Community',
    playing: 14000,
    rating: 4.6,
    imageUrl: 'https://picsum.photos/400/225?random=5',
    category: 'FPS'
  },
  {
    id: '6',
    title: 'Pet Simulator 99',
    creator: 'BIG Games',
    playing: 210000,
    rating: 4.7,
    imageUrl: 'https://picsum.photos/400/225?random=6',
    category: 'Simulator'
  },
  {
    id: '7',
    title: 'Doors',
    creator: 'LSPLASH',
    playing: 56000,
    rating: 4.9,
    imageUrl: 'https://picsum.photos/400/225?random=7',
    category: 'Horror'
  },
  {
    id: '8',
    title: 'Jailbreak',
    creator: 'Badimo',
    playing: 25000,
    rating: 4.4,
    imageUrl: 'https://picsum.photos/400/225?random=8',
    category: 'Action'
  },
];

export const AVATAR_COLORS = [
  '#e8beac', // Skin
  '#a36d56', // Darker Skin
  '#633c2e', // Dark Skin
  '#00a2ff', // Blue
  '#ff0000', // Red
  '#00ff00', // Green
  '#ffff00', // Yellow
  '#1b1b1b', // Black
  '#ffffff', // White
  '#808080', // Grey
  '#ff00ff', // Purple
  '#ffa500', // Orange
];