import React, { useState } from 'react';
import { AppState, ViewState, User, Game } from './types';
import { INITIAL_USER } from './constants';
import Navbar from './components/Navbar';
import AuthPage from './components/AuthPage';
import Home from './components/Home';
import GamesList from './components/GamesList';
import AvatarEditor from './components/AvatarEditor';
import GameClient from './components/GameClient';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    view: ViewState.AUTH,
    user: INITIAL_USER,
    activeGame: null
  });

  const handleLogin = () => {
    setState(prev => ({ ...prev, view: ViewState.HOME }));
  };

  const handleLogout = () => {
    setState(prev => ({ ...prev, view: ViewState.AUTH, activeGame: null }));
  };

  const setView = (view: ViewState) => {
    setState(prev => ({ ...prev, view }));
  };

  const handlePlayGame = (game: Game) => {
    setState(prev => ({ ...prev, activeGame: game, view: ViewState.GAME_CLIENT }));
  };

  const handleLeaveGame = () => {
    setState(prev => ({ ...prev, activeGame: null, view: ViewState.HOME }));
  };

  const handleUpdateAvatar = (newColors: User['avatarColors']) => {
    if (state.user) {
        setState(prev => ({
            ...prev,
            user: { ...prev.user!, avatarColors: newColors }
        }));
    }
  };

  if (state.view === ViewState.AUTH) {
    return <AuthPage onLogin={handleLogin} />;
  }

  if (state.view === ViewState.GAME_CLIENT && state.activeGame && state.user) {
    return <GameClient game={state.activeGame} user={state.user} onLeave={handleLeaveGame} />;
  }

  return (
    <div className="min-h-screen bg-rblx-dark text-rblx-text font-sans">
      {state.user && (
        <Navbar 
            user={state.user} 
            currentView={state.view} 
            setView={setView} 
            onLogout={handleLogout}
        />
      )}
      
      <main className="pt-12">
        {state.view === ViewState.HOME && state.user && (
            <Home user={state.user} onPlayGame={handlePlayGame} />
        )}
        {state.view === ViewState.GAMES && (
            <GamesList onPlayGame={handlePlayGame} />
        )}
        {state.view === ViewState.AVATAR && state.user && (
            <AvatarEditor user={state.user} onUpdateAvatar={handleUpdateAvatar} />
        )}
      </main>
    </div>
  );
};

export default App;