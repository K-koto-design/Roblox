import React, { useState } from 'react';
import { ViewState, User } from '../types';

interface NavbarProps {
  user: User;
  currentView: ViewState;
  setView: (view: ViewState) => void;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, currentView, setView, onLogout }) => {
  const [showSettings, setShowSettings] = useState(false);

  const navItemClass = (active: boolean) => 
    `flex items-center justify-center px-4 h-full border-b-2 transition-colors cursor-pointer hover:bg-rblx-light ${active ? 'border-white text-white' : 'border-transparent text-gray-300'}`;

  return (
    <nav className="h-12 bg-rblx-panel border-b border-rblx-light flex items-center justify-between px-4 fixed top-0 w-full z-50 select-none">
      <div className="flex items-center space-x-6 h-full">
        {/* Logo */}
        <div 
          className="text-2xl font-black italic tracking-tighter cursor-pointer hover:opacity-80 transition-opacity"
          onClick={() => setView(ViewState.HOME)}
        >
          <span className="border-2 border-white px-1 mr-1 rounded-sm text-lg inline-block transform -skew-x-12"></span>
          roblox
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex h-full text-sm font-semibold">
          <div 
            className={navItemClass(currentView === ViewState.HOME)}
            onClick={() => setView(ViewState.HOME)}
          >
            Discover
          </div>
          <div 
             className={navItemClass(currentView === ViewState.GAMES)}
             onClick={() => setView(ViewState.GAMES)}
          >
            Marketplace
          </div>
          <div className={navItemClass(false)}>Create</div>
          <div 
            className={navItemClass(false)} // Robux link
          >
            <span className="font-bold">10% More</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex-1 max-w-2xl px-6 hidden sm:block">
        <div className="relative group">
          <input 
            type="text" 
            placeholder="Search" 
            className="w-full bg-rblx-dark border border-gray-600 rounded-full py-1.5 px-10 text-sm focus:outline-none focus:border-white focus:bg-black transition-all"
          />
          <div className="absolute left-3 top-2 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
      </div>

      {/* Right Icons */}
      <div className="flex items-center space-x-4 h-full">
         <div 
            className="flex items-center space-x-1 cursor-pointer hover:opacity-80"
            title={`${user.robux} Robux`}
         >
            <div className="w-5 h-5 border-2 border-white rounded-sm transform rotate-45 flex items-center justify-center text-[10px] font-bold">
               <div className="transform -rotate-45">$</div>
            </div>
            <span className="text-sm font-bold hidden md:block">{user.robux.toLocaleString()}</span>
         </div>

         <div className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-rblx-light cursor-pointer">
            <i className="fas fa-bell text-white text-lg"></i>
         </div>

         <div 
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-rblx-light cursor-pointer"
            onClick={() => setView(ViewState.AVATAR)}
         >
            <i className="fas fa-user-circle text-white text-xl"></i>
         </div>

         <div className="relative">
            <div 
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-rblx-light cursor-pointer"
              onClick={() => setShowSettings(!showSettings)}
            >
                <i className="fas fa-cog text-white text-xl"></i>
            </div>
            
            {showSettings && (
              <div className="absolute right-0 top-10 w-48 bg-rblx-panel border border-rblx-light rounded-lg shadow-xl py-2 z-50">
                <div className="px-4 py-2 hover:bg-rblx-light cursor-pointer">Settings</div>
                <div className="px-4 py-2 hover:bg-rblx-light cursor-pointer">Help</div>
                <div className="border-t border-gray-700 my-1"></div>
                <div 
                  className="px-4 py-2 hover:bg-rblx-light cursor-pointer text-red-400"
                  onClick={() => {
                    setShowSettings(false);
                    onLogout();
                  }}
                >
                  Logout
                </div>
              </div>
            )}
         </div>
      </div>
    </nav>
  );
};

export default Navbar;