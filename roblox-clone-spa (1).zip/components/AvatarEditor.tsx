import React, { useState } from 'react';
import { User } from '../types';
import { AVATAR_COLORS } from '../constants';

interface AvatarEditorProps {
  user: User;
  onUpdateAvatar: (newColors: User['avatarColors']) => void;
}

const AvatarEditor: React.FC<AvatarEditorProps> = ({ user, onUpdateAvatar }) => {
  const [activeTab, setActiveTab] = useState<'Recent' | 'Body' | 'Clothing'>('Body');
  const [activeBodyPart, setActiveBodyPart] = useState<keyof User['avatarColors']>('torso');

  const handleColorSelect = (color: string) => {
    onUpdateAvatar({
      ...user.avatarColors,
      [activeBodyPart]: color
    });
  };

  const bodyPartsDisplay: { id: keyof User['avatarColors']; label: string }[] = [
    { id: 'head', label: 'Head' },
    { id: 'torso', label: 'Torso' },
    { id: 'leftArm', label: 'Left Arm' },
    { id: 'rightArm', label: 'Right Arm' },
    { id: 'leftLeg', label: 'Left Leg' },
    { id: 'rightLeg', label: 'Right Leg' },
  ];

  return (
    <div className="flex flex-col md:flex-row h-[calc(100vh-3rem)] overflow-hidden">
      {/* Left: Preview */}
      <div className="md:w-1/2 lg:w-1/3 bg-gradient-to-b from-slate-700 to-slate-900 flex flex-col items-center justify-center p-8 relative">
        <h2 className="absolute top-4 left-4 text-2xl font-bold opacity-50">Avatar Editor</h2>
        
        {/* SVG Avatar Representation */}
        <div className="w-64 h-64 md:w-96 md:h-96 relative filter drop-shadow-2xl">
          <svg viewBox="0 0 200 300" className="w-full h-full">
             {/* Left Arm */}
             <rect x="20" y="55" width="40" height="90" rx="10" fill={user.avatarColors.leftArm} stroke="#000" strokeWidth="2" />
             {/* Right Arm */}
             <rect x="140" y="55" width="40" height="90" rx="10" fill={user.avatarColors.rightArm} stroke="#000" strokeWidth="2" />
             {/* Left Leg */}
             <rect x="65" y="150" width="32" height="100" rx="5" fill={user.avatarColors.leftLeg} stroke="#000" strokeWidth="2" />
             {/* Right Leg */}
             <rect x="103" y="150" width="32" height="100" rx="5" fill={user.avatarColors.rightLeg} stroke="#000" strokeWidth="2" />
             {/* Torso */}
             <rect x="60" y="55" width="80" height="100" rx="5" fill={user.avatarColors.torso} stroke="#000" strokeWidth="2" />
             {/* Head */}
             <rect x="75" y="10" width="50" height="50" rx="10" fill={user.avatarColors.head} stroke="#000" strokeWidth="2" />
             {/* Face - Simple */}
             <circle cx="90" cy="30" r="3" fill="black" />
             <circle cx="110" cy="30" r="3" fill="black" />
             <path d="M 90 40 Q 100 48 110 40" stroke="black" strokeWidth="2" fill="none" />
          </svg>
        </div>
        
        <div className="mt-8 flex space-x-4">
            <button className="bg-rblx-blue text-white px-8 py-2 rounded font-bold hover:bg-blue-600 transition-colors shadow-lg">
                Redraw
            </button>
        </div>
      </div>

      {/* Right: Controls */}
      <div className="md:w-1/2 lg:w-2/3 bg-rblx-dark p-4 md:p-8 overflow-y-auto">
        
        {/* Tabs */}
        <div className="flex border-b border-gray-600 mb-6">
            {['Recent', 'Body', 'Clothing', 'Animations'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`px-6 py-3 font-bold text-sm transition-colors ${activeTab === tab ? 'border-b-2 border-white text-white' : 'text-gray-400 hover:text-white'}`}
                >
                    {tab}
                </button>
            ))}
        </div>

        {activeTab === 'Body' && (
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-bold mb-3 text-white">Select Body Part</h3>
                    <div className="flex flex-wrap gap-2">
                        {bodyPartsDisplay.map(part => (
                            <button
                                key={part.id}
                                onClick={() => setActiveBodyPart(part.id)}
                                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                                    activeBodyPart === part.id 
                                    ? 'bg-white text-black shadow-md scale-105' 
                                    : 'bg-rblx-light text-gray-300 hover:bg-gray-600'
                                }`}
                            >
                                {part.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div>
                    <h3 className="text-lg font-bold mb-3 text-white">Skin Tone / Color</h3>
                    <div className="grid grid-cols-6 sm:grid-cols-8 gap-3">
                        {AVATAR_COLORS.map(color => (
                            <button
                                key={color}
                                onClick={() => handleColorSelect(color)}
                                style={{ backgroundColor: color }}
                                className={`w-10 h-10 rounded-full border-2 transition-transform hover:scale-110 ${
                                    user.avatarColors[activeBodyPart] === color 
                                    ? 'border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] scale-110' 
                                    : 'border-transparent'
                                }`}
                                aria-label={`Select color ${color}`}
                            />
                        ))}
                    </div>
                </div>
            </div>
        )}

        {activeTab !== 'Body' && (
            <div className="text-center py-20 text-gray-500">
                <i className="fas fa-hammer text-4xl mb-4"></i>
                <p>This section is under construction.</p>
            </div>
        )}

        <div className="mt-12 border-t border-gray-700 pt-6 flex justify-end space-x-4">
             <button className="text-gray-400 hover:text-white font-semibold">Cancel</button>
             <button className="bg-white text-black px-6 py-2 rounded font-bold hover:bg-gray-200">Save</button>
        </div>
      </div>
    </div>
  );
};

export default AvatarEditor;