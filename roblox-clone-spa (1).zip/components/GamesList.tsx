import React, { useState } from 'react';
import { Game } from '../types';
import { MOCK_GAMES } from '../constants';

interface GamesListProps {
  onPlayGame: (game: Game) => void;
}

const CATEGORIES = ['All', 'Popular', 'Top Rated', 'Adventure', 'RP', 'FPS', 'Obby', 'Tycoon', 'Simulator'];

const GamesList: React.FC<GamesListProps> = ({ onPlayGame }) => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredGames = activeCategory === 'All' 
    ? MOCK_GAMES 
    : MOCK_GAMES.filter(g => g.category === activeCategory || (activeCategory === 'Popular' && g.playing > 100000));

  // If filtered list is small, just duplicate it to look full for the demo
  const displayGames = filteredGames.length < 4 ? [...filteredGames, ...filteredGames] : filteredGames;

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto pb-20">
      <h1 className="text-3xl font-bold mb-6">Discover</h1>
      
      {/* Filters */}
      <div className="flex overflow-x-auto space-x-2 pb-6 mb-4 scrollbar-hide">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
              activeCategory === cat 
                ? 'bg-white text-black' 
                : 'bg-rblx-light text-white hover:bg-gray-600'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {displayGames.map((game, idx) => (
          <div 
            key={`${game.id}-${idx}`} 
            className="group cursor-pointer"
            onClick={() => onPlayGame(game)}
          >
             <div className="relative rounded-lg overflow-hidden aspect-square mb-2 bg-rblx-light">
                 <img src={game.imageUrl} alt={game.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"/>
             </div>
             <div>
                <h3 className="font-bold text-base truncate">{game.title}</h3>
                <div className="text-xs text-gray-400 truncate">{game.creator}</div>
                <div className="flex items-center justify-between mt-1 text-xs text-gray-400">
                    <span className="flex items-center">
                        <i className="fas fa-thumbs-up mr-1 text-gray-500"></i>
                        {(game.rating * 20).toFixed(0)}%
                    </span>
                    <span className="flex items-center">
                        <i className="fas fa-user mr-1 text-gray-500"></i>
                        {(game.playing / 1000).toFixed(1)}k
                    </span>
                </div>
             </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GamesList;