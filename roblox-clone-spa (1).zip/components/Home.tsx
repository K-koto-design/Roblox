import React from 'react';
import { Game, User } from '../types';
import { MOCK_GAMES } from '../constants';

interface HomeProps {
  user: User;
  onPlayGame: (game: Game) => void;
}

const Home: React.FC<HomeProps> = ({ user, onPlayGame }) => {
  const continueGames = MOCK_GAMES.slice(0, 3);

  const GameCard: React.FC<{ game: Game, layout?: 'portrait' | 'landscape' }> = ({ game, layout = 'portrait' }) => (
    <div 
        className="group cursor-pointer flex flex-col" 
        onClick={() => onPlayGame(game)}
    >
        <div className="relative overflow-hidden rounded-lg">
            <img 
                src={game.imageUrl} 
                alt={game.title} 
                className={`w-full object-cover transition-transform duration-300 group-hover:scale-110 ${layout === 'landscape' ? 'aspect-video' : 'aspect-square'}`}
            />
            {/* Play Overlay */}
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                <div className="bg-green-500 rounded-full w-12 h-12 flex items-center justify-center shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-transform">
                    <i className="fas fa-play text-white ml-1"></i>
                </div>
            </div>
        </div>
        <div className="mt-2">
            <h3 className="font-bold text-white text-lg truncate hover:underline">{game.title}</h3>
            
            <div className="flex items-center justify-between text-xs text-gray-400 mt-1">
                 <div className="flex items-center space-x-1">
                     <i className="fas fa-thumbs-up text-gray-500"></i>
                     <span>{(game.rating * 20).toFixed(0)}%</span>
                 </div>
                 <div className="flex items-center space-x-1">
                     <i className="fas fa-user text-gray-500"></i>
                     <span>{(game.playing / 1000).toFixed(1)}k</span>
                 </div>
            </div>
        </div>
    </div>
  );

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-20">
        {/* Welcome Section */}
        <div>
            <h1 className="text-3xl font-bold mb-4">Home</h1>
            <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-rblx-light border-2 border-gray-600">
                    <svg viewBox="0 0 100 100" className="w-full h-full">
                       <rect width="100" height="100" fill="#2c2c2c"/>
                       <circle cx="50" cy="40" r="20" fill={user.avatarColors.head} />
                       <rect x="25" y="60" width="50" height="40" rx="10" fill={user.avatarColors.torso} />
                    </svg>
                </div>
                <div className="text-xl font-bold text-white">{user.username}</div>
            </div>
        </div>

        {/* Continue Playing */}
        <section>
            <div className="flex justify-between items-end mb-4">
                <h2 className="text-xl font-bold">Continue</h2>
                <span className="text-xs font-bold text-rblx-blue hover:underline cursor-pointer">See All <i className="fas fa-arrow-right ml-1"></i></span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {continueGames.map(game => (
                    <GameCard key={game.id} game={game} layout="landscape" />
                ))}
            </div>
        </section>

        {/* Recommended */}
        <section>
            <h2 className="text-xl font-bold mb-4">Recommended for You</h2>
            <div className="flex overflow-x-auto space-x-4 pb-4 -mx-4 px-4 scrollbar-hide">
                {MOCK_GAMES.map(game => (
                    <div key={game.id} className="min-w-[160px] md:min-w-[200px]">
                        <GameCard game={game} layout="landscape" />
                    </div>
                ))}
            </div>
        </section>

         {/* Favorites */}
         <section>
            <h2 className="text-xl font-bold mb-4">Your Favorites</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {[...MOCK_GAMES].reverse().slice(0, 6).map(game => (
                    <GameCard key={game.id} game={game} />
                ))}
            </div>
        </section>
    </div>
  );
};

export default Home;