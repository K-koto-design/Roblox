import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Game, User } from '../types';

interface GameClientProps {
  game: Game;
  user: User;
  onLeave: () => void;
}

const GameClient: React.FC<GameClientProps> = ({ game, user, onLeave }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<{user: string, text: string}[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [showPlayerList, setShowPlayerList] = useState(true);
  
  // Loading state management
  const [loadingState, setLoadingState] = useState<'loading' | 'fading' | 'finished'>('loading');

  useEffect(() => {
      const timer1 = setTimeout(() => setLoadingState('fading'), 1500);
      const timer2 = setTimeout(() => setLoadingState('finished'), 2500);
      return () => {
          clearTimeout(timer1);
          clearTimeout(timer2);
      };
  }, []);

  // Initial fake messages
  useEffect(() => {
    setMessages([
        { user: 'System', text: `Welcome to ${game.title}!` },
        { user: 'NoobMaster69', text: 'Anyone wanna trade?' }
    ]);
  }, [game.title]);

  // Three.js Game Loop
  useEffect(() => {
    if (!mountRef.current) return;

    // --- SCENE SETUP ---
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB); // Roblox Sky Blue
    scene.fog = new THREE.Fog(0x87CEEB, 20, 100);

    // --- CAMERA ---
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    
    // --- RENDERER ---
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    mountRef.current.appendChild(renderer.domElement);

    // --- LIGHTING ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(50, 100, 50);
    dirLight.castShadow = true;
    dirLight.shadow.camera.left = -50;
    dirLight.shadow.camera.right = 50;
    dirLight.shadow.camera.top = 50;
    dirLight.shadow.camera.bottom = -50;
    scene.add(dirLight);

    // --- ENVIRONMENT ---
    // Ground (Baseplate)
    const groundGeometry = new THREE.PlaneGeometry(200, 200);
    const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x4CAF50 });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Random Cubes (Decorations)
    const cubeGeo = new THREE.BoxGeometry(4, 4, 4);
    const cubeMat = new THREE.MeshStandardMaterial({ color: 0xA0522D });
    
    for(let i=0; i<10; i++) {
        const cube = new THREE.Mesh(cubeGeo, cubeMat);
        cube.position.set(
            (Math.random() - 0.5) * 100, 
            2, 
            (Math.random() - 0.5) * 100
        );
        cube.castShadow = true;
        cube.receiveShadow = true;
        scene.add(cube);
    }

    // --- PLAYER (R6 AVATAR) ---
    const playerGroup = new THREE.Group();
    playerGroup.position.y = 3; // Start slightly above ground
    scene.add(playerGroup);

    // Helper to create parts
    const createPart = (w: number, h: number, d: number, color: string, x: number, y: number, z: number) => {
        const geo = new THREE.BoxGeometry(w, h, d);
        const mat = new THREE.MeshStandardMaterial({ color: color });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(x, y, z);
        mesh.castShadow = true;
        return mesh;
    };

    // Construct Body Parts
    const torso = createPart(2, 2, 1, user.avatarColors.torso, 0, 0, 0); // Center
    const head = createPart(1.2, 1.2, 1.2, user.avatarColors.head, 0, 1.6, 0); // Above Torso
    const leftArm = createPart(1, 2, 1, user.avatarColors.leftArm, -1.5, 0, 0);
    const rightArm = createPart(1, 2, 1, user.avatarColors.rightArm, 1.5, 0, 0);
    const leftLeg = createPart(1, 2, 1, user.avatarColors.leftLeg, -0.5, -2, 0);
    const rightLeg = createPart(1, 2, 1, user.avatarColors.rightLeg, 0.5, -2, 0);

    // Add smiley face to head
    const faceTextureCanvas = document.createElement('canvas');
    faceTextureCanvas.width = 64;
    faceTextureCanvas.height = 64;
    const faceCtx = faceTextureCanvas.getContext('2d');
    if (faceCtx) {
        faceCtx.fillStyle = user.avatarColors.head;
        faceCtx.fillRect(0, 0, 64, 64);
        faceCtx.fillStyle = 'black';
        // Eyes
        faceCtx.fillRect(18, 24, 6, 6);
        faceCtx.fillRect(40, 24, 6, 6);
        // Smile
        faceCtx.beginPath();
        faceCtx.arc(32, 35, 12, 0.2 * Math.PI, 0.8 * Math.PI);
        faceCtx.stroke();
    }
    const faceTex = new THREE.CanvasTexture(faceTextureCanvas);
    // Apply texture only to front face of head is tricky with single material, 
    // so strictly speaking we stick to solid colors for "simple" but let's try mapping simple Texture
    head.material = new THREE.MeshStandardMaterial({ map: faceTex });

    playerGroup.add(torso);
    playerGroup.add(head);
    playerGroup.add(leftArm);
    playerGroup.add(rightArm);
    playerGroup.add(leftLeg);
    playerGroup.add(rightLeg);

    // --- GAME LOGIC STATE ---
    const keys: { [key: string]: boolean } = {};
    const playerVelocity = new THREE.Vector3();
    const speed = 0.3;
    const jumpForce = 0.5;
    const gravity = 0.02;
    let isGrounded = false;
    let walkCycle = 0;

    const handleKeyDown = (e: KeyboardEvent) => {
        // Chat blocking
        if (document.activeElement?.tagName === 'INPUT') return;
        keys[e.code] = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
        keys[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    const handleResize = () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // --- ANIMATION LOOP ---
    const animate = () => {
        requestAnimationFrame(animate);

        // Movement Logic
        const moveDir = new THREE.Vector3(0, 0, 0);
        let isMoving = false;

        if (keys['KeyW']) { moveDir.z -= 1; isMoving = true; }
        if (keys['KeyS']) { moveDir.z += 1; isMoving = true; }
        if (keys['KeyA']) { moveDir.x -= 1; isMoving = true; }
        if (keys['KeyD']) { moveDir.x += 1; isMoving = true; }

        if (isMoving) {
            moveDir.normalize().multiplyScalar(speed);
            playerGroup.position.add(moveDir);
            
            // Rotate character to face movement direction
            const targetRotation = Math.atan2(moveDir.x, moveDir.z);
            // Simple lerp rotation
            const rotDiff = targetRotation - playerGroup.rotation.y;
            // Normalize angle logic skipped for simplicity, essentially instant turn or simple lerp
            playerGroup.rotation.y = targetRotation;

            // Walk animation (Swing limbs)
            walkCycle += 0.2;
            leftArm.rotation.x = Math.cos(walkCycle) * 0.5;
            rightArm.rotation.x = Math.cos(walkCycle + Math.PI) * 0.5;
            leftLeg.rotation.x = Math.cos(walkCycle + Math.PI) * 0.5;
            rightLeg.rotation.x = Math.cos(walkCycle) * 0.5;
        } else {
            // Reset Pose
            leftArm.rotation.x = 0;
            rightArm.rotation.x = 0;
            leftLeg.rotation.x = 0;
            rightLeg.rotation.x = 0;
            walkCycle = 0;
        }

        // Jumping & Gravity
        if (keys['Space'] && isGrounded) {
            playerVelocity.y = jumpForce;
            isGrounded = false;
        }

        playerVelocity.y -= gravity;
        playerGroup.position.y += playerVelocity.y;

        // Ground Collision (Simple Y check)
        // Leg height is 2, Torso is 2. Center of torso is 0 local. 
        // Torso center is playerGroup.y. Legs extend down 2 units from torso center (0 to -2).
        // Total height from group center to feet is roughly 3 units.
        const playerHeightOffset = 3; 
        if (playerGroup.position.y < playerHeightOffset) {
            playerGroup.position.y = playerHeightOffset;
            playerVelocity.y = 0;
            isGrounded = true;
        }

        // Camera Follow (Third Person)
        const cameraOffset = new THREE.Vector3(0, 10, 15); // High and back
        const targetPos = playerGroup.position.clone().add(cameraOffset);
        camera.position.lerp(targetPos, 0.1); // Smooth follow
        camera.lookAt(playerGroup.position);

        renderer.render(scene, camera);
    };

    animate();

    // CLEANUP
    return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
        window.removeEventListener('resize', handleResize);
        if (mountRef.current) {
            mountRef.current.removeChild(renderer.domElement);
        }
        // Dispose Three.js resources
        groundGeometry.dispose();
        groundMaterial.dispose();
        renderer.dispose();
    };
  }, [user]); // Re-run if user appearance changes

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setMessages(prev => [...prev, { user: user.username, text: chatInput }]);
    setChatInput('');
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      {/* Container for Three.js Canvas */}
      <div ref={mountRef} className="w-full h-full cursor-none" />

      {/* Top Bar (In-Game) */}
      <div className="absolute top-0 left-0 right-0 h-12 bg-gray-900 bg-opacity-80 flex items-center justify-between px-4 z-20 select-none">
         <div 
            className="w-8 h-8 rounded hover:bg-white hover:bg-opacity-20 flex items-center justify-center cursor-pointer transition-colors"
            onClick={() => setShowMenu(true)}
        >
             <div className="w-5 h-5 flex flex-col justify-between">
                <span className="h-0.5 bg-white w-full"></span>
                <span className="h-0.5 bg-white w-full"></span>
                <span className="h-0.5 bg-white w-full"></span>
             </div>
         </div>
         <div className="flex space-x-4">
             <i className="fas fa-microphone text-white opacity-50 cursor-not-allowed"></i>
             <div 
                className="bg-gray-800 px-3 py-1 rounded text-white text-sm font-bold cursor-pointer hover:bg-gray-700"
                onClick={() => setShowPlayerList(!showPlayerList)}
             >
                <i className="fas fa-users mr-2"></i>
                Players
             </div>
         </div>
      </div>

      {/* Menu Overlay */}
      {showMenu && (
        <div className="absolute inset-0 bg-black bg-opacity-70 flex z-50">
            <div className="w-64 bg-rblx-panel h-full p-4 border-r border-gray-600">
                <h2 className="text-2xl font-bold mb-6 text-white border-b border-gray-600 pb-2">Menu</h2>
                <div className="space-y-2">
                    <button className="w-full text-left p-3 text-gray-300 hover:bg-rblx-light rounded">Settings</button>
                    <button className="w-full text-left p-3 text-gray-300 hover:bg-rblx-light rounded">Help</button>
                    <button className="w-full text-left p-3 text-gray-300 hover:bg-rblx-light rounded">Report</button>
                </div>
                <div className="mt-auto absolute bottom-4 w-56 space-y-2">
                    <button onClick={() => { 
                        setShowMenu(false);
                    }} className="w-full py-2 border border-white rounded text-white hover:bg-white hover:text-black">Resume</button>
                    <button 
                        onClick={onLeave}
                        className="w-full py-2 bg-red-600 rounded text-white hover:bg-red-700"
                    >
                        Leave Game
                    </button>
                </div>
            </div>
            <div className="flex-1" onClick={() => setShowMenu(false)}></div>
        </div>
      )}

      {/* Player List */}
      {showPlayerList && (
          <div className="absolute top-14 right-4 w-48 bg-gray-900 bg-opacity-80 rounded-lg p-2 text-white text-sm z-10 pointer-events-none">
              <div className="font-bold border-b border-gray-600 pb-1 mb-1 px-1">Leaderboard</div>
              <div className="space-y-1">
                  <div className="flex items-center px-1">
                      <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                      {user.username}
                  </div>
                  <div className="flex items-center px-1 text-gray-300">
                      <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                      NoobMaster69
                  </div>
                  <div className="flex items-center px-1 text-gray-300">
                      <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                      Builderman
                  </div>
              </div>
          </div>
      )}

      {/* Chat */}
      <div className="absolute top-14 left-4 w-72 h-48 flex flex-col z-10">
          <div className="flex-1 bg-gray-900 bg-opacity-60 rounded-t-lg p-2 overflow-y-auto scrollbar-hide">
              {messages.map((msg, i) => (
                  <div key={i} className="mb-1 text-sm shadow-black drop-shadow-md">
                      <span className="font-bold text-white">[{msg.user}]: </span>
                      <span className="text-white">{msg.text}</span>
                  </div>
              ))}
          </div>
          <form onSubmit={handleChatSubmit} className="bg-gray-900 bg-opacity-80 p-1 rounded-b-lg flex">
              <input 
                  type="text" 
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  placeholder="Click here to chat"
                  className="bg-transparent text-white text-sm w-full px-2 py-1 focus:outline-none"
              />
          </form>
      </div>

      {/* Loading Overlay */}
      {loadingState !== 'finished' && (
          <div 
            className={`absolute inset-0 bg-black z-50 flex flex-col items-center justify-center pointer-events-none transition-opacity duration-1000 ${loadingState === 'fading' ? 'opacity-0' : 'opacity-100'}`}
          >
              <div className="w-16 h-16 border-4 border-rblx-blue border-t-transparent rounded-full animate-spin mb-4"></div>
              <div className="text-xl font-bold text-white">Joining Server...</div>
          </div>
      )}
    </div>
  );
};

export default GameClient;