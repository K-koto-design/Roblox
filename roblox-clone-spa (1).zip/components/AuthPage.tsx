import React, { useState } from 'react';

interface AuthPageProps {
  onLogin: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (username.length > 0 && password.length > 0) {
      setIsLoading(true);
      // Simulate network request
      setTimeout(() => {
        setIsLoading(false);
        onLogin();
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-800 to-slate-900 flex flex-col items-center justify-center p-4">
      {/* Logo */}
      <div className="mb-8 text-center">
        <div className="text-6xl font-black italic tracking-tighter text-white inline-flex items-center">
            <span className="border-4 border-white w-12 h-12 flex items-center justify-center mr-3 rounded-lg transform -skew-x-12"></span>
            roblox
        </div>
      </div>

      <div className="bg-rblx-panel w-full max-w-md p-8 rounded-xl shadow-2xl border border-rblx-light">
        <h2 className="text-2xl font-bold mb-6 text-center text-white">
          {isLoginMode ? 'Login to Roblox' : 'Sign Up to Start Having Fun!'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLoginMode && (
             <div className="flex space-x-2">
                 <select className="bg-rblx-dark border border-gray-600 text-white p-2 rounded w-1/3">
                    <option>Month</option>
                    <option>January</option>
                    <option>February</option>
                 </select>
                 <select className="bg-rblx-dark border border-gray-600 text-white p-2 rounded w-1/3">
                    <option>Day</option>
                    {[...Array(31)].map((_, i) => <option key={i}>{i+1}</option>)}
                 </select>
                 <select className="bg-rblx-dark border border-gray-600 text-white p-2 rounded w-1/3">
                    <option>Year</option>
                    {[...Array(50)].map((_, i) => <option key={i}>{2023-i}</option>)}
                 </select>
             </div>
          )}

          <div>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-rblx-dark border border-gray-600 rounded-lg p-3 text-white focus:outline-none focus:border-white transition-colors"
            />
            {!isLoginMode && <p className="text-xs text-gray-400 mt-1">Don't use your real name</p>}
          </div>

          <div>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-rblx-dark border border-gray-600 rounded-lg p-3 text-white focus:outline-none focus:border-white transition-colors"
            />
             {!isLoginMode && <p className="text-xs text-gray-400 mt-1">At least 8 characters</p>}
          </div>

          {!isLoginMode && (
             <div className="flex space-x-2 my-2">
                 <div className="flex-1 bg-rblx-dark border border-gray-600 rounded p-2 text-center cursor-pointer hover:bg-gray-700">
                     <i className="fas fa-female mr-2"></i> Female
                 </div>
                 <div className="flex-1 bg-rblx-dark border border-gray-600 rounded p-2 text-center cursor-pointer hover:bg-gray-700">
                     <i className="fas fa-male mr-2"></i> Male
                 </div>
             </div>
          )}

          <button
            type="submit"
            className="w-full bg-rblx-blue hover:bg-blue-600 text-white font-bold py-3 rounded-lg transition-colors flex justify-center items-center"
          >
            {isLoading ? (
               <i className="fas fa-spinner fa-spin"></i>
            ) : (
                isLoginMode ? 'Log In' : 'Sign Up'
            )}
          </button>
        </form>

        {isLoginMode && (
          <div className="mt-4 text-center">
            <div className="text-sm text-gray-400 mb-4">
               <label className="flex items-center justify-center cursor-pointer space-x-2">
                 <input type="checkbox" className="form-checkbox bg-rblx-dark border-gray-600" />
                 <span>Remember Me</span>
               </label>
            </div>
            <a href="#" className="text-xs text-rblx-blue hover:underline block mb-4">Forgot Password or Username?</a>
            
            <div className="border-t border-gray-600 pt-4">
              <p className="text-gray-400 text-sm mb-2">Don't have an account?</p>
              <button 
                 onClick={() => setIsLoginMode(false)}
                 className="w-full border border-white text-white py-2 rounded-lg hover:bg-white hover:text-black transition-colors font-semibold"
              >
                Sign Up
              </button>
            </div>
          </div>
        )}
        
        {!isLoginMode && (
             <div className="mt-4 text-center border-t border-gray-600 pt-4">
              <p className="text-gray-400 text-sm mb-2">Already have an account?</p>
              <button 
                 onClick={() => setIsLoginMode(true)}
                 className="w-full border border-white text-white py-2 rounded-lg hover:bg-white hover:text-black transition-colors font-semibold"
              >
                Log In
              </button>
            </div>
        )}

      </div>
      
      <div className="mt-8 text-gray-500 text-xs text-center">
         ©2024 Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.
      </div>
    </div>
  );
};

export default AuthPage;