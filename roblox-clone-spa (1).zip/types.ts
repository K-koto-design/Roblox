export enum ViewState {
  AUTH = 'AUTH',
  HOME = 'HOME',
  GAMES = 'GAMES',
  AVATAR = 'AVATAR',
  GAME_CLIENT = 'GAME_CLIENT'
}

export interface User {
  username: string;
  robux: number;
  avatarColors: {
    head: string;
    torso: string;
    leftArm: string;
    rightArm: string;
    leftLeg: string;
    rightLeg: string;
  };
}

export interface Game {
  id: string;
  title: string;
  creator: string;
  playing: number;
  rating: number; // 0-5
  imageUrl: string;
  category: string;
}

export interface AppState {
  view: ViewState;
  user: User | null;
  activeGame: Game | null;
}